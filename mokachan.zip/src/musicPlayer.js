import { Player } from "discord-player";
import { DefaultExtractors } from "@discord-player/extractor";
import { YoutubeiExtractor } from "discord-player-youtubei";
import youtubedl from "youtube-dl-exec";

// ==================== MUSIC PLAYER (SINGLETON) ====================
// Menggunakan discord-player: library ini otomatis punya extractor
// untuk resolve link Spotify / Apple Music / SoundCloud playlist,
// lalu mencari padanannya di YouTube untuk di-stream audionya
// (Spotify Web API tidak menyediakan raw audio stream, jadi ini
// pendekatan standar yang dipakai bot-bot musik seperti Jockie Music).

let playerInstance = null;

/**
 * Inisialisasi player. Panggil SEKALI saat bot start (sebelum/ saat client ready).
 * @param {import("discord.js").Client} client
 */
export async function initMusicPlayer(client) {
  if (playerInstance) return playerInstance;

  playerInstance = new Player(client);

  // Load extractor bawaan (Spotify, Apple Music, SoundCloud, dll),
  // tapi exclude YouTubeExtractor bawaan karena kita pakai extractor
  // pihak ketiga (discord-player-youtubei) yang lebih tahan terhadap
  // perubahan/anti-bot YouTube.
  const extractorsWithoutYouTube = DefaultExtractors.filter(
    (ext) => ext.name !== "YouTubeExtractor"
  );
  await playerInstance.extractors.loadMulti(extractorsWithoutYouTube);

  // youtubei.js (dipakai discord-player-youtubei) saat ini sering kena 400
  // dari endpoint /youtubei/v1/player karena YouTube memperketat anti-bot
  // (butuh PoToken, dsb) -- ini isu yang sedang dialami banyak project
  // berbasis youtubei.js, bukan cuma di sini. Sebagai workaround, kita
  // override createStream supaya pengambilan URL audio dilakukan lewat
  // yt-dlp (biasanya lebih cepat diupdate mengikuti perubahan YouTube)
  // alih-alih lewat request Innertube yang lagi bermasalah.
  await playerInstance.extractors.register(YoutubeiExtractor, {
    streamOptions: {
      useClient: "ANDROID",
    },
    createStream: async (track) => {
      const url = await youtubedl(track.url, {
        quiet: true,
        format: "bestaudio",
        getUrl: true,
        noWarnings: true,
        noCheckCertificates: true,
        preferFreeFormats: true,
      });

      const directUrl = String(url).trim().split("\n")[0];

      if (!directUrl) {
        throw new Error("yt-dlp gagal mendapatkan URL audio untuk track ini.");
      }

      return directUrl;
    },
  });

  playerInstance.events.on("error", (queue, error) => {
    console.error(`[Player Error] guild ${queue?.guild?.name}:`, error);
  });

  playerInstance.events.on("playerError", (queue, error) => {
    console.error(`[Track Error] guild ${queue?.guild?.name}:`, error);
  });

  playerInstance.events.on("playerStart", (queue, track) => {
    const channel = queue.metadata?.channel;
    if (channel) {
      const author = track?.author?.trim();
      const looksCorrupted = !author || /\band\s+\d+\s+more\b/i.test(author) || author.length > 60;
      channel.send(
        `▶️ Sekarang memutar: **${track.title}** — ${looksCorrupted ? "Unknown Artist" : author}`
      );
    }
  });

  playerInstance.events.on("emptyQueue", (queue) => {
    console.log(`ℹ️ [Debug] emptyQueue terpicu untuk guild ${queue?.guild?.name}`);
    const channel = queue.metadata?.channel;
    if (channel) channel.send("📭 Antrean habis, keluar dari voice channel.");
  });

  playerInstance.events.on("playerSkip", (queue, track) => {
    console.log(`ℹ️ [Debug] playerSkip: ${track?.title}`);
  });

  playerInstance.events.on("disconnect", (queue) => {
    console.log(`ℹ️ [Debug] disconnect terpicu untuk guild ${queue?.guild?.name}`);
  });

  playerInstance.events.on("emptyChannel", (queue) => {
    console.log(`ℹ️ [Debug] emptyChannel (voice channel kosong) untuk guild ${queue?.guild?.name}`);
  });

  playerInstance.events.on("audioTrackAdd", (queue, track) => {
    console.log(`ℹ️ [Debug] audioTrackAdd: ${track?.title}`);
  });

  // Log super detail dari discord-player itu sendiri (streaming, extractor, dll)
  playerInstance.on("debug", (message) => {
    console.log(`[PlayerDebug] ${message}`);
  });

  console.log("🎧 Music player siap.");
  return playerInstance;
}

/**
 * Ambil instance player yang sudah diinisialisasi.
 * Lempar error kalau belum dipanggil initMusicPlayer() lebih dulu.
 */
export function getMusicPlayer() {
  if (!playerInstance) {
    throw new Error(
      "Music player belum di-init. Pastikan initMusicPlayer(client) dipanggil di index.js sebelum command musik dipakai."
    );
  }
  return playerInstance;
}