import { QueryType } from "discord-player";
import { getMusicPlayer } from "../musicPlayer.js";

// ==================== SOURCE FLAGS ====================
// Mirip Jockie Music: bisa maksa sumber pencarian lewat flag di awal query.
// Kalau tidak pakai flag, discord-player otomatis mendeteksi:
// - Link YouTube / YouTube Music -> diputar langsung
// - Link Spotify (track/playlist/album) -> di-resolve ke YouTube otomatis
// - Link SoundCloud / Apple Music -> diputar langsung
// - Teks biasa -> di-search ke YouTube (default)
const SOURCE_FLAGS = {
  "-yt": QueryType.YOUTUBE_SEARCH,
  "-youtube": QueryType.YOUTUBE_SEARCH,
  "-sc": QueryType.SOUNDCLOUD_SEARCH,
  "-soundcloud": QueryType.SOUNDCLOUD_SEARCH,
};

// ==================== HELPERS ====================

// youtubei.js kadang salah parsing rich-text metadata YouTube dan
// menghasilkan nama author yang rusak (mis. "Aku eńau and 2 more").
// Fallback ke "Unknown Artist" kalau kelihatan tidak wajar.
function safeAuthor(track) {
  const author = track?.author?.trim();
  if (!author) return "Unknown Artist";

  const looksCorrupted =
    /\band\s+\d+\s+more\b/i.test(author) || // pola "and 2 more"
    author.length > 60; // nama channel normal tidak sepanjang itu

  return looksCorrupted ? "Unknown Artist" : author;
}

function getVoiceChannel(msg) {
  return msg.member?.voice?.channel ?? null;
}

function getQueue(msg) {
  const player = getMusicPlayer();
  return player.nodes.get(msg.guild.id);
}

// ==================== PLAY ====================
// Bisa terima: judul lagu, link video YouTube, link playlist YouTube,
// link track Spotify, atau link playlist/album Spotify.

export async function handlePlayCommand(client, msg, query) {
  if (!query) {
    return msg.reply(
      "Tulis judul lagu, link YouTube, atau link playlist/track Spotify setelah command.\n" +
        "Bisa juga paksa sumber tertentu: `-yt <judul>` (YouTube) atau `-sc <judul>` (SoundCloud)."
    );
  }

  // Cek apakah user maksa sumber tertentu, mis. "-sc telolet remix"
  let searchEngine = QueryType.AUTO;
  const firstWord = query.split(" ")[0].toLowerCase();
  if (SOURCE_FLAGS[firstWord]) {
    searchEngine = SOURCE_FLAGS[firstWord];
    query = query.slice(firstWord.length).trim();
  }

  if (!query) {
    return msg.reply("Tulis judul lagu setelah flag sumbernya.");
  }

  const voiceChannel = getVoiceChannel(msg);
  if (!voiceChannel) {
    return msg.reply("Kamu harus join voice channel dulu sebelum play musik.");
  }

  const permissions = voiceChannel.permissionsFor(client.user);
  if (!permissions?.has("Connect") || !permissions?.has("Speak")) {
    return msg.reply("Aku butuh izin **Connect** & **Speak** di voice channel itu.");
  }

  const player = getMusicPlayer();
  const loadingMsg = await msg.reply(`🔎 Mencari **${query}**...`);

  try {
    const { track, searchResult } = await player.play(voiceChannel, query, {
      searchEngine,
      nodeOptions: {
        metadata: { channel: msg.channel, requestedBy: msg.author.tag },
        selfDeaf: true,
        volume: 80,
        leaveOnEmpty: true,
        leaveOnEmptyCooldown: 60_000,
        leaveOnEnd: true,
        leaveOnEndCooldown: 60_000,
        leaveOnStop: true,
      },
      requestedBy: msg.author,
    });

    if (searchResult.playlist) {
      return loadingMsg.edit(
        `🎶 Playlist **${searchResult.playlist.title}** (${searchResult.tracks.length} lagu) ditambahkan ke antrean.`
      );
    }

    return loadingMsg.edit(
      `🎵 **${track.title}** — ${safeAuthor(track)} (${track.source}) ditambahkan ke antrean.`
    );
  } catch (error) {
    console.error("Gagal memutar lagu:", error);
    return loadingMsg.edit(
      `Gagal memutar lagu dari sumber ini: ${error.message}\n` +
        `Coba sumber lain, mis. \`play -sc ${query}\` untuk cari di SoundCloud.`
    );
  }
}

// ==================== SKIP ====================

export function handleSkipCommand(msg) {
  const queue = getQueue(msg);
  if (!queue || !queue.isPlaying()) {
    return msg.reply("Tidak ada lagu yang sedang diputar.");
  }
  const current = queue.currentTrack;
  const success = queue.node.skip();
  return msg.reply(success ? `⏭️ Skip **${current.title}**.` : "Gagal skip lagu.");
}

// ==================== STOP ====================

export function handleStopCommand(msg) {
  const queue = getQueue(msg);
  if (!queue) return msg.reply("Tidak ada antrean yang aktif.");
  queue.delete();
  return msg.reply("⏹️ Musik dihentikan dan antrean dikosongkan.");
}

// ==================== PAUSE / RESUME ====================

export function handlePauseCommand(msg) {
  const queue = getQueue(msg);
  if (!queue || !queue.isPlaying()) return msg.reply("Tidak ada lagu yang sedang diputar.");
  if (queue.node.isPaused()) return msg.reply("⏸️ Sudah dalam keadaan pause.");
  queue.node.pause();
  return msg.reply("⏸️ Musik dipause.");
}

export function handleResumeCommand(msg) {
  const queue = getQueue(msg);
  if (!queue) return msg.reply("Tidak ada antrean yang aktif.");
  if (!queue.node.isPaused()) return msg.reply("▶️ Musik sedang tidak dipause.");
  queue.node.resume();
  return msg.reply("▶️ Musik dilanjutkan.");
}

// ==================== QUEUE ====================

export function handleQueueCommand(msg) {
  const queue = getQueue(msg);
  if (!queue || (!queue.currentTrack && queue.tracks.size === 0)) {
    return msg.reply("📭 Antrean kosong.");
  }

  const current = queue.currentTrack
    ? `▶️ Sedang diputar: **${queue.currentTrack.title}** — ${safeAuthor(queue.currentTrack)}`
    : "";

  const upcoming = queue.tracks
    .toArray()
    .slice(0, 10)
    .map((t, i) => `${i + 1}. ${t.title} — ${safeAuthor(t)}`)
    .join("\n");

  const more =
    queue.tracks.size > 10 ? `\n...dan ${queue.tracks.size - 10} lagu lainnya di antrean.` : "";

  return msg.reply(`${current}\n\n**Antrean berikutnya:**\n${upcoming || "-"}${more}`);
}

// ==================== NOW PLAYING ====================

export function handleNowPlayingCommand(msg) {
  const queue = getQueue(msg);
  if (!queue || !queue.currentTrack) {
    return msg.reply("Tidak ada lagu yang sedang diputar.");
  }
  const track = queue.currentTrack;
  const progress = queue.node.createProgressBar();
  return msg.reply(`🎵 **${track.title}** — ${safeAuthor(track)}\n${progress ?? ""}`);
}

// ==================== VOLUME ====================

export function handleVolumeCommand(msg, args) {
  const queue = getQueue(msg);
  if (!queue) return msg.reply("Tidak ada antrean yang aktif.");

  const raw = args?.trim();
  if (!raw) return msg.reply(`🔊 Volume sekarang: **${queue.node.volume}%**`);

  const value = Number(raw);
  if (!Number.isInteger(value) || value < 0 || value > 100) {
    return msg.reply("Volume harus angka 0-100. Contoh: `volume 80`");
  }

  queue.node.setVolume(value);
  return msg.reply(`🔊 Volume diatur ke **${value}%**.`);
}

// ==================== LOOP ====================
// mode: off | track | queue

export function handleLoopCommand(msg, args) {
  const queue = getQueue(msg);
  if (!queue) return msg.reply("Tidak ada antrean yang aktif.");

  const mode = args?.trim().toLowerCase();
  const modeMap = { off: 0, track: 1, queue: 2 };

  if (!mode || !(mode in modeMap)) {
    return msg.reply("Pilih mode loop: `off`, `track`, atau `queue`. Contoh: `loop queue`");
  }

  queue.setRepeatMode(modeMap[mode]);
  return msg.reply(`🔁 Loop mode diatur ke **${mode}**.`);
}

// ==================== SHUFFLE ====================

export function handleShuffleCommand(msg) {
  const queue = getQueue(msg);
  if (!queue || queue.tracks.size === 0) {
    return msg.reply("Tidak ada cukup lagu di antrean untuk di-shuffle.");
  }
  queue.tracks.shuffle();
  return msg.reply("🔀 Antrean diacak.");
}

// ==================== LEAVE ====================

export function handleLeaveCommand(msg) {
  const queue = getQueue(msg);
  if (!queue) return msg.reply("Bot sedang tidak di voice channel manapun.");
  queue.delete();
  return msg.reply("👋 Keluar dari voice channel.");
}